// express
const express = require('express');
const req = require('express/lib/request');
const app = express();
// bodyparser
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// ejs
app.set('view engine', 'ejs');

// mongodb
const MongoClient = require('mongodb').MongoClient;

// mongodb 연동, server open
let creditDBUrl = 'mongodb+srv://admin:qwer1234@cluster0.pi799.mongodb.net/creditDB?retryWrites=true&w=majority';
let creditDB;
MongoClient.connect(creditDBUrl, (error, result) => {
    if (error) {
        return (
            console.log('MongoDB connection failed ', error)
        );
    }
    creditDB = result.db('creditDB');
    console.log('MongoDB connection success');

    app.listen(8080, () => {
        console.log('port opened success');
    })

})

// '/'로 index.ejs
app.get('/', (req, res) => {
    creditDB.collection('credit').find().toArray((error, result) => {
        if (error) {
            return (
                console.log('DB search failed', error)
            );
        }
        res.render('index.ejs', { creditData: result });
    })
})

// '/insert'로 insert.ejs
app.get('/insert', (req, res) => {
    res.render('insert.ejs');
})

// '/add'로 post, mongodb client에 save
app.post('/add', (req, res) => {
    creditDB.collection('postcount').findOne({ total_count: 'total_count' }, (error, result) => {
        if (error) {
            return (
                console.log('total_count find failed', error)
            );
        }
        let totalCount = result.sequence_num;
        creditDB.collection('credit').insertOne({
            _id: totalCount + 1, user_name: req.body.user_name, user_credit: Number(req.body.user_credit)
        }, (error, result) => {
            if (error) {
                return (
                    console.log('creditDB save failed ', error)
                );
            }
            console.log('creditDB save success');
            creditDB.collection('postcount').updateOne({ total_count: 'total_count' }, { $inc: { sequence_num: 1 } }, (error, result) => {
                if (error) {
                    return (
                        console.log('total_count, sequence_num update failed', error)
                    );
                }
                res.redirect('/');
            })
        })
    });
})

// delete
app.delete('/delete', (req, res) => {
    creditDB.collection('credit').deleteOne({ _id: Number(req.body._id) }, (error, result) => {
        if (error) {
            return (
                console.log('creditDB delete failed', error)
            );
        }
        console.log('creditDB delete success');
    })
    res.redirect('/');
})
